package com.backend.api.features.task.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.backend.api.features.task.model.Task;

@Repository
public interface TaskRepository extends JpaRepository<Task, UUID> {

    @Query("SELECT t FROM Task t JOIN FETCH t.creator LEFT JOIN FETCH t.assignedTo WHERE t.assignedTo IS NULL ORDER BY t.createdAt DESC")
    List<Task> findByAssignedToIsNullOrderByCreatedAtDesc();

    @Query("SELECT t FROM Task t JOIN FETCH t.creator LEFT JOIN FETCH t.assignedTo WHERE t.creator.email = :email ORDER BY t.createdAt DESC")
    List<Task> findByCreatorEmailOrderByCreatedAtDesc(@Param("email") String email);
}