package com.backend.api.features.task.service;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.backend.api.features.auth.model.User;
import com.backend.api.features.auth.repository.UserRepository;
import com.backend.api.features.task.model.Task;
import com.backend.api.features.task.repository.TaskRepository;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public TaskService(TaskRepository taskRepository, UserRepository userRepository) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public Object createTask(String email, Map<String, Object> body) {
        try {
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) return Map.of("success", false, "error", "User not found");

            Task task = new Task();
            task.setCreator(userOpt.get());
            task.setTitle(body.getOrDefault("title", "").toString());
            task.setDescription(body.getOrDefault("description", "").toString());
            task.setCategory(body.getOrDefault("category", "All Tasks").toString());
            task.setLocation(body.getOrDefault("location", "").toString());
            task.setPrice(new BigDecimal(body.getOrDefault("price", "0").toString()));
            
            Object urgentObj = body.get("urgent");
            task.setUrgent(urgentObj != null && Boolean.parseBoolean(urgentObj.toString()));

            taskRepository.save(task);
            return Map.of("success", true, "message", "Task created successfully!");
        } catch (Exception e) {
            return Map.of("success", false, "error", e.getMessage());
        }
    }

    @Transactional
    public Object editTask(String email, UUID taskId, Map<String, Object> body) {
        try {
            Task task = taskRepository.findById(taskId).orElseThrow(() -> new Exception("Task not found"));
            if (!task.getCreator().getEmail().equalsIgnoreCase(email)) return Map.of("success", false, "error", "Unauthorized");

            if (body.containsKey("title")) task.setTitle(body.get("title").toString());
            if (body.containsKey("description")) task.setDescription(body.get("description").toString());
            if (body.containsKey("category")) task.setCategory(body.get("category").toString());
            if (body.containsKey("location")) task.setLocation(body.get("location").toString());
            if (body.containsKey("price")) task.setPrice(new BigDecimal(body.get("price").toString()));
            if (body.containsKey("urgent")) task.setUrgent(Boolean.parseBoolean(body.get("urgent").toString()));

            taskRepository.save(task);
            return Map.of("success", true);
        } catch (Exception e) { return Map.of("success", false, "error", e.getMessage()); }
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getAvailableTasks() {
        // This only shows tasks where assignedTo IS NULL
        return taskRepository.findByAssignedToIsNullOrderByCreatedAtDesc()
                .stream()
                .map(this::mapTaskToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getMyPosts(String email) {
        // This shows ALL tasks you created, even if assigned!
        return taskRepository.findByCreatorEmailOrderByCreatedAtDesc(email)
                .stream()
                .map(this::mapTaskToDto)
                .collect(Collectors.toList());
    }

    private Map<String, Object> mapTaskToDto(Task task) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", task.getId());
        dto.put("title", task.getTitle());
        dto.put("description", task.getDescription());
        dto.put("category", task.getCategory());
        dto.put("location", task.getLocation());
        dto.put("price", task.getPrice());
        dto.put("urgent", task.isUrgent());
        
        // Add a "Virtual Status" so the frontend has something to read
        // even if it's not in your database table yet.
        dto.put("status", task.getAssignedTo() != null ? "ASSIGNED" : "OPEN");

        // Use a null-safe check for the creator
        dto.put("creatorEmail", task.getCreator() != null ? task.getCreator().getEmail() : "Unknown"); 
        
        // Safely fetch assigned user email
        if (task.getAssignedTo() != null) {
            dto.put("assignedToEmail", task.getAssignedTo().getEmail());
        } else {
            dto.put("assignedToEmail", null);
        }
        
        return dto;
    }
}