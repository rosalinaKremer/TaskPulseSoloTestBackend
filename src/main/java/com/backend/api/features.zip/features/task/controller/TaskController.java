package com.backend.api.features.task.controller;

import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.backend.api.features.task.service.TaskService;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    public ResponseEntity<?> createTask(@RequestParam("email") String email, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(taskService.createTask(email, body));
    }

    @GetMapping("/available")
    public ResponseEntity<?> getAvailableTasks() {
        return ResponseEntity.ok(taskService.getAvailableTasks());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editTask(@RequestParam("email") String email, @PathVariable("id") UUID id, @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(taskService.editTask(email, id, body));
    }

    @GetMapping("/my-posts")
    public ResponseEntity<?> getMyPosts(@RequestParam("email") String email) {
        return ResponseEntity.ok(taskService.getMyPosts(email));
    }
}